
const net = new brain.NeuralNetwork();

const data=[{
input:{
q1: 1,
q2: 1,
q3: 1,
q4: 1,q5: 1,
q6: 1,q7: 1,
q8: 1,q9: 1,q10: 1,
},
output:[1]
},{input:{
    q1: 0,
    q2: 0,
    q3: 0,
    q4: 0,q5: 0,
    q6: 0,q7: 0,
    q8: 0,q9: 0,q10: 0,
    },
    output:[0]
    }
    ,{input:{
        q1: 1,
        q2: 1,
        q3: 1,
        q4: 1,q5: 1,
        q6: 1,q7: 1,
        q8: 0,q9: 0,q10: 0,
        },
        output:[1]
        }
        ,{input:{
            q1: 0,
            q2: 0,
            q3: 0,
            q4: 1,q5: 1,
            q6: 1,q7: 0,
            q8: 0,q9: 0,q10: 0,
            },
            output:[0]
            }
]
var temp,currentprediction=''
net.train(data)
function changeDiv(val) {
    var section1 = document.getElementById('section1');
    var section2 = document.getElementById('section2');
    var section3 = document.getElementById('section3');
    var section3cat = document.getElementById('section3cat');
    var section3dog = document.getElementById('section3dog');
    var heading = document.getElementById('heading');
    

    if (val == 0) {
        section1.style.display = 'flex';
        section2.style.display = 'none';
        section3.style.display = 'none';
        heading.style.display = 'flex';
        clearRadioButtons();
    } else if (val == 1) {
        section1.style.display = 'none';
        section2.style.display = 'block';
        heading.style.display = 'none';

    } else if (val == 2) {
        heading.style.display = 'none';
        const selectedValues = getSelectedValues();
        console.log(selectedValues<0.5,selectedValues);
        if (selectedValues!=null && selectedValues<0.5) {
            currentprediction='cat'
            section1.style.display = 'none';
            section2.style.display = 'none';
            section3.style.display = 'block';
            section3cat.style.display='block'
            section3dog.style.display='none'
        }
        else if (selectedValues!=null && selectedValues>0.5) {
            currentprediction='dog'
            section1.style.display = 'none';
            section2.style.display = 'none';
            section3.style.display = 'block';
            section3dog.style.display='block'
            section3cat.style.display='none'

        }
        
    }
}

function getSelectedValues() {
    var selectedValues = [];
    var questionGroups = document.querySelectorAll('.card'); 
    var allSelected = true;

    questionGroups.forEach(function(group, groupIndex) {
        var radioButtons = group.querySelectorAll('input[type="radio"][name^="ques"]'); 
        var anySelected = false;

        radioButtons.forEach(function(button) {
            if (button.checked) {
                anySelected = true;
                selectedValues.push({ [`q${groupIndex+1}`]: button.value });
                return; 
            }
        });

        if (!anySelected) {
            allSelected = false;
            return; 
        }
    });

    if (!allSelected) {
        alert("Please select an option for each question.");
        return null;
    }
    
    const mergedObject = selectedValues.reduce((acc, obj, index) => {
        const key = `q${index + 1}`;
        acc[key] = parseInt(obj[key], 10);
        return acc;
      }, {});
      
      temp=mergedObject;
    console.log(temp);
    console.log(net.run(temp))
    return net.run(temp)[0];
}

function predStatus(val)
{
if(!val)
{
    console.log(temp);
    data.push({input:temp,output:[currentprediction=='cat'?1:0
 

]})
alert('Thanks for the Feedback')

changeDiv(0)
}
else{
    alert('Thanks for the Feedback')
    changeDiv(0)
}
console.log(data);

}
function clearRadioButtons() {
    var questionGroups = document.querySelectorAll('.card');
    questionGroups.forEach(function(group) {
        var radioButtons = group.querySelectorAll('input[type="radio"][name^="ques"]');
        radioButtons.forEach(function(button) {
            button.checked = false;
        });
    });
}